﻿Write-Host " "
Write-Host "Uploading Configurations"
Write-Host " "
Write-Host "The SCRIPT file is being processed - Please wait..."
Write-Host " "

$(

function FileProgress
{
  Param($e)
  if ($e.FileProgress -ne $Null)
  {
    $transferSpeed = 0
    if ($e.CPS -ne $Null)
    {$transferSpeed = $e.CPS}
    $filePercent = $e.FileProgress*100
    
    Write-Progress -activity "FTP Upload" -status ("Uploading " + $e.FileName) -percentComplete ($filePercent) -CurrentOperation ("Completed: " + $filePercent + "% @ " + [Math]::Round(($transferSpeed/1024),2) + " k/bytes per second")
  }
}

try
{
    # Load WinSCP .NET assembly
    # Use "winscp.dll" for the releases before the latest beta version.
    [Reflection.Assembly]::LoadFrom("C:\UPLOAD\WinSCPnet.dll") | Out-Null

    # Config
    $username = "admin"
    $password = "admin"
    $dataFile = "C:\UPLOAD\cards.txt"
    $localDir = "C:\UPLOAD\cfg\"
 

$file = Get-Content $DataFile

Write-Host 'The SCRIPT file is being processed'

foreach ($line in $file) 
{ 
    $fields = $line.split("`t") 
    $localFile = "$($LocalDir)$($fields[0].Trim()).txt"
    $remoteFile = "router.cfg"
    
    # Setup session options
    $sessionOptions = New-Object WinSCP.SessionOptions
    $sessionOptions.Protocol = [WinSCP.Protocol]::ftp
    $sessionOptions.HostName = $fields[1].Trim()
    $sessionOptions.UserName = $username
    $sessionOptions.Password = $password
 
    $session = New-Object WinSCP.Session
 
    try
    {
        Write-Host "Connecting to...$($fields[1])"
        $session.add_FileTransferProgress( { FileProgress($_) } )
        
        # Connect
        $session.Open($sessionOptions)
 
        # Upload files
        $transferOptions = New-Object WinSCP.TransferOptions
        $transferOptions.TransferMode = [WinSCP.TransferMode]::Binary
 
        $transferResult = $session.PutFiles($localFile, $remoteFile, $False, $transferOptions)
 
        # Throw on any error
        $transferResult.Check()
        
        $session.ExecuteCommand("site savebuffer").Check() 

        $session.ExecuteCommand("site reload on").Check() 
 
        # Print results
        foreach ($transfer in $transferResult.Transfers)
        {
            Write-Host ("Upload of {0} succeeded" -f $transfer.FileName)
            Write-Host "Successful Upload to...$($fields[1])"
        }
    }
    catch [Exception]
    {
        Write-Host $_.Exception.Message
        Write-Host "Unsuccessful Upload to...$($fields[1])"
    }
    finally
    {
        # Disconnect, clean up
        $session.Dispose()
    }
    Write-Host "End of operation to...$($fields[1])"
}
#Write-Host " "
Write-Host "*** UPLOAD SCRIPT COMPLETED ***"
exit 0
}
catch [Exception]
{
#    Write-Host $_.Exception.Message
    exit 1
}
) *>&1 > "C:\UPLOAD\output.txt"